/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.resource.v1;

import java.util.function.Function;

import org.jetbrains.annotations.ApiStatus;

import net.minecraft.core.HolderLookup;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.PreparableReloadListener;

import net.fabricmc.fabric.impl.resource.DataResourceLoaderImpl;

/**
 * Provides various hooks into the {@linkplain net.minecraft.server.packs.PackType#SERVER_DATA server data} resource loader.
 */
@ApiStatus.NonExtendable
public interface DataResourceLoader extends ResourceLoader {
	/**
	 * The reload listener state key for the data resource store.
	 *
	 * @apiNote The data resource store is only available in {@linkplain PackType#SERVER_DATA server data} reload listeners.
	 * <br/>
	 * It should <b>only</b> be mutated in the application phase of the reload listeners.
	 */
	PreparableReloadListener.StateKey<DataResourceStore.Mutable> DATA_RESOURCE_STORE_KEY = new PreparableReloadListener.StateKey<>();

	static DataResourceLoader get() {
		return DataResourceLoaderImpl.INSTANCE;
	}

	/**
	 * Registers a data reload listener.
	 *
	 * @param id the identifier of the reload listener
	 * @param factory the factory function of the reload listener
	 * @see #registerReloadListener(Identifier, PreparableReloadListener)
	 * @see #addListenerOrdering(Identifier, Identifier)
	 *
	 * @apiNote In most cases {@link #registerReloadListener(Identifier, PreparableReloadListener)} is sufficient and should be preferred,
	 * but for some reload listeners like {@link net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener} constructing the reload listener
	 * with a known instance of the holder lookup is required.
	 * <br/>
	 * While this may encourage stateful reload listeners, it is best to primarily use reload listeners as stateless loaders,
	 * as storing a state may easily lead to incomplete or leaking data.
	 */
	void registerReloadListener(
			Identifier id,
			Function<HolderLookup.Provider, PreparableReloadListener> factory
	);
}
