/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.recipe.sync;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeMap;
import net.minecraft.world.item.crafting.RecipeSerializer;

import net.fabricmc.fabric.impl.recipe.sync.RecipeSyncImpl;
import net.fabricmc.fabric.impl.recipe.sync.SyncedSerializerAwarePreparedRecipe;

@Mixin(RecipeMap.class)
public class RecipeMapMixin implements SyncedSerializerAwarePreparedRecipe {
	@Unique
	private Map<RecipeSerializer<?>, List<RecipeHolder<?>>> bySyncedSerializer;

	@ModifyReturnValue(method = "create", at = @At("RETURN"))
	private static RecipeMap attachSerializerMap(RecipeMap original) {
		var map = new IdentityHashMap<RecipeSerializer<?>, List<RecipeHolder<?>>>();

		for (RecipeSerializer<?> serializer : RecipeSyncImpl.getSyncedSerializers()) {
			map.put(serializer, new ArrayList<>());
		}

		for (RecipeHolder<?> recipe : original.values()) {
			List<RecipeHolder<?>> list = map.get(recipe.value().getSerializer());

			if (list != null) {
				list.add(recipe);
			}
		}

		((RecipeMapMixin) (Object) original).bySyncedSerializer = map;
		return original;
	}

	@Override
	public @Nullable List<RecipeHolder<?>> fabric_getRecipesBySyncedSerializer(RecipeSerializer<?> serializer) {
		//noinspection unchecked
		return this.bySyncedSerializer.get(serializer);
	}
}
