/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.client.indigo.renderer.mesh;

import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.HEADER_BITS;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.HEADER_TAG;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.HEADER_TINT_INDEX;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.VERTEX_COLOR;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.VERTEX_LIGHTMAP;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.VERTEX_NORMAL;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.VERTEX_STRIDE;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.VERTEX_U;
import static net.fabricmc.fabric.impl.client.indigo.renderer.mesh.EncodingFormat.VERTEX_X;

import java.util.Objects;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jspecify.annotations.Nullable;

import net.minecraft.client.model.geom.builders.UVPair;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.Direction;
import net.minecraft.util.LightCoordsUtil;

import net.fabricmc.fabric.api.client.renderer.v1.mesh.QuadAtlas;
import net.fabricmc.fabric.api.client.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.client.renderer.v1.mesh.QuadTransform;
import net.fabricmc.fabric.api.client.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.api.client.renderer.v1.mesh.ShadeMode;
import net.fabricmc.fabric.api.util.TriState;
import net.fabricmc.fabric.impl.client.indigo.renderer.helper.NormalHelper;

/**
 * Almost-concrete implementation of a mutable quad. The only missing part is {@link #emitDirectly()},
 * because that depends on where/how it is used. (Mesh encoding vs. render-time transformation).
 *
 * <p>In many cases an instance of this class is used as an "editor quad". The editor quad's
 * {@link #emitDirectly()} method calls some other internal method that transforms the quad
 * data and then buffers it. Transformations should be the same as they would be in a vanilla
 * render - the editor is serving mainly as a way to access vertex data without magical
 * numbers. It also allows for a consistent interface for those transformations.
 */
public abstract class MutableQuadViewImpl extends QuadViewImpl implements QuadEmitter {
	private static final QuadTransform NO_TRANSFORM = _ -> true;

	private static final int[] DEFAULT_QUAD_DATA = new int[EncodingFormat.TOTAL_STRIDE];

	static {
		MutableQuadViewImpl quad = new MutableQuadViewImpl() {
			@Override
			protected void emitDirectly() {
				// This quad won't be emitted. It's only used to configure the default quad data.
			}
		};

		// Start with all zeroes
		quad.data = DEFAULT_QUAD_DATA;
		// Apply non-zero defaults
		quad.color(-1, -1, -1, -1);
		quad.cullFace(null);
		quad.chunkLayer(ChunkSectionLayer.CUTOUT);
		quad.itemRenderType(ItemRenderType.DEFAULT.renderType);
		quad.itemGlintRenderType(ItemGlintRenderType.DEFAULT.renderType);
		quad.itemGlintSpecialRenderType(ItemGlintSpecialRenderType.DEFAULT.renderType);
		quad.shadeDirectionOverride(null);
		quad.ambientOcclusion(TriState.DEFAULT);
		quad.foilType(null);
		quad.tintIndex(-1);
	}

	private QuadTransform activeTransform = NO_TRANSFORM;
	private final ObjectArrayList<QuadTransform> transformStack = new ObjectArrayList<>();
	private final QuadTransform stackTransform = q -> {
		int i = transformStack.size() - 1;

		while (i >= 0) {
			if (!transformStack.get(i--).transform(q)) {
				return false;
			}
		}

		return true;
	};

	@Override
	public final MutableQuadViewImpl pos(int vertexIndex, float x, float y, float z) {
		final int index = baseIndex + vertexIndex * VERTEX_STRIDE + VERTEX_X;
		data[index] = Float.floatToRawIntBits(x);
		data[index + 1] = Float.floatToRawIntBits(y);
		data[index + 2] = Float.floatToRawIntBits(z);
		isGeometryInvalid = true;
		return this;
	}

	@Override
	public final MutableQuadViewImpl translate(float x, float y, float z) {
		for (int i = 0; i < 4; i++) {
			final int index = baseIndex + i * VERTEX_STRIDE + VERTEX_X;
			data[index] = Float.floatToRawIntBits(Float.intBitsToFloat(data[index]) + x);
			data[index + 1] = Float.floatToRawIntBits(Float.intBitsToFloat(data[index + 1]) + y);
			data[index + 2] = Float.floatToRawIntBits(Float.intBitsToFloat(data[index + 2]) + z);
		}

		// In reality, only the CUBIC and LIGHT_FACE flags need to be invalidated.
		// AXIS_ALIGNED and the face normal are unchanged after translation.
		isGeometryInvalid = true;
		return this;
	}

	@Override
	public final MutableQuadViewImpl color(int vertexIndex, int color) {
		data[baseIndex + vertexIndex * VERTEX_STRIDE + VERTEX_COLOR] = color;
		return this;
	}

	@Override
	public final MutableQuadViewImpl uv(int vertexIndex, float u, float v) {
		final int i = baseIndex + vertexIndex * VERTEX_STRIDE + VERTEX_U;
		data[i] = Float.floatToRawIntBits(u);
		data[i + 1] = Float.floatToRawIntBits(v);
		return this;
	}

	@Override
	public final MutableQuadViewImpl lightmap(int vertexIndex, int lightmap) {
		data[baseIndex + vertexIndex * VERTEX_STRIDE + VERTEX_LIGHTMAP] = lightmap;
		return this;
	}

	protected final void normalFlags(int flags) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.normalFlags(data[baseIndex + HEADER_BITS], flags);
	}

	@Override
	public final MutableQuadViewImpl normal(int vertexIndex, float x, float y, float z) {
		normalFlags(normalFlags() | (1 << vertexIndex));
		data[baseIndex + vertexIndex * VERTEX_STRIDE + VERTEX_NORMAL] = NormalHelper.packNormal(x, y, z);
		return this;
	}

	/**
	 * Internal helper method. Copies face normal to vertices lacking a normal.
	 */
	public final void populateMissingNormals() {
		final int normalFlags = this.normalFlags();

		if (normalFlags == 0b1111) return;

		final int packedFaceNormal = packedFaceNormal();

		for (int v = 0; v < 4; v++) {
			if ((normalFlags & (1 << v)) == 0) {
				data[baseIndex + v * VERTEX_STRIDE + VERTEX_NORMAL] = packedFaceNormal;
			}
		}

		normalFlags(0b1111);
	}

	@Override
	public final MutableQuadViewImpl nominalFace(@Nullable Direction face) {
		nominalFace = face;
		return this;
	}

	@Override
	public final MutableQuadViewImpl cullFace(@Nullable Direction face) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.cullFace(data[baseIndex + HEADER_BITS], face);
		nominalFace(face);
		return this;
	}

	@Override
	public MutableQuadViewImpl chunkLayer(ChunkSectionLayer layer) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.chunkLayer(data[baseIndex + HEADER_BITS], layer);
		return this;
	}

	@Override
	public MutableQuadViewImpl itemRenderType(RenderType renderType) {
		ItemRenderType enumValue = ItemRenderType.RENDER_TYPE_TO_ENUM.get(renderType);

		if (enumValue != null) {
			data[baseIndex + HEADER_BITS] = EncodingFormat.itemRenderType(data[baseIndex + HEADER_BITS], enumValue);
		}

		return this;
	}

	@Override
	public MutableQuadViewImpl itemGlintRenderType(RenderType renderType) {
		ItemGlintRenderType enumValue = ItemGlintRenderType.RENDER_TYPE_TO_ENUM.get(renderType);

		if (enumValue != null) {
			data[baseIndex + HEADER_BITS] = EncodingFormat.itemGlintRenderType(data[baseIndex + HEADER_BITS], enumValue);
		}

		return this;
	}

	@Override
	public MutableQuadViewImpl itemGlintSpecialRenderType(RenderType renderType) {
		ItemGlintSpecialRenderType enumValue = ItemGlintSpecialRenderType.RENDER_TYPE_TO_ENUM.get(renderType);

		if (enumValue != null) {
			data[baseIndex + HEADER_BITS] = EncodingFormat.itemGlintSpecialRenderType(data[baseIndex + HEADER_BITS], enumValue);
		}

		return this;
	}

	@Override
	public MutableQuadViewImpl emissive(boolean emissive) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.emissive(data[baseIndex + HEADER_BITS], emissive);
		return this;
	}

	@Override
	public MutableQuadViewImpl shadeDirectionOverride(@Nullable Direction shadeDirection) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.shadeDirectionOverride(data[baseIndex + HEADER_BITS], shadeDirection);
		return this;
	}

	@Override
	public MutableQuadViewImpl ambientOcclusion(TriState ao) {
		Objects.requireNonNull(ao, "ambient occlusion TriState may not be null");
		data[baseIndex + HEADER_BITS] = EncodingFormat.ambientOcclusion(data[baseIndex + HEADER_BITS], ao);
		return this;
	}

	@Override
	public MutableQuadViewImpl foilType(ItemStackRenderState.@Nullable FoilType foilType) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.foilType(data[baseIndex + HEADER_BITS],
				foilType
		);
		return this;
	}

	@Override
	public MutableQuadViewImpl shadeMode(ShadeMode mode) {
		Objects.requireNonNull(mode, "ShadeMode may not be null");
		data[baseIndex + HEADER_BITS] = EncodingFormat.shadeMode(data[baseIndex + HEADER_BITS], mode);
		return this;
	}

	@Override
	public MutableQuadViewImpl animated(boolean animated) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.animated(data[baseIndex + HEADER_BITS], animated);
		return this;
	}

	@Override
	public MutableQuadViewImpl atlas(QuadAtlas quadAtlas) {
		data[baseIndex + HEADER_BITS] = EncodingFormat.quadAtlas(data[baseIndex + HEADER_BITS], quadAtlas);
		return this;
	}

	@Override
	public final MutableQuadViewImpl tintIndex(int tintIndex) {
		data[baseIndex + HEADER_TINT_INDEX] = tintIndex;
		return this;
	}

	@Override
	public final MutableQuadViewImpl tag(int tag) {
		data[baseIndex + HEADER_TAG] = tag;
		return this;
	}

	@Override
	public final MutableQuadViewImpl copyFrom(QuadView quad) {
		final QuadViewImpl q = (QuadViewImpl) quad;
		System.arraycopy(q.data, q.baseIndex, data, baseIndex, EncodingFormat.TOTAL_STRIDE);
		nominalFace = q.nominalFace;
		isGeometryInvalid = q.isGeometryInvalid;

		if (!isGeometryInvalid) {
			faceNormal.set(q.faceNormal);
		}

		return this;
	}

	@Override
	public final MutableQuadViewImpl fromBakedQuad(BakedQuad quad) {
		BakedQuad.MaterialInfo materialInfo = quad.materialInfo();

		pos(0, quad.position0());
		pos(1, quad.position1());
		pos(2, quad.position2());
		pos(3, quad.position3());

		color(0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF);

		long packedUV0 = quad.packedUV0();
		long packedUV1 = quad.packedUV1();
		long packedUV2 = quad.packedUV2();
		long packedUV3 = quad.packedUV3();
		uv(0, UVPair.unpackU(packedUV0), UVPair.unpackV(packedUV0));
		uv(1, UVPair.unpackU(packedUV1), UVPair.unpackV(packedUV1));
		uv(2, UVPair.unpackU(packedUV2), UVPair.unpackV(packedUV2));
		uv(3, UVPair.unpackU(packedUV3), UVPair.unpackV(packedUV3));

		int lightEmission = materialInfo.lightEmission();
		int lightmap = LightCoordsUtil.pack(lightEmission, lightEmission);
		lightmap(lightmap, lightmap, lightmap, lightmap);

		normalFlags(0);

		nominalFace(quad.direction());

		QuadAtlas atlas = QuadAtlas.ofLocation(materialInfo.sprite().atlasLocation());

		if (atlas == null) {
			atlas = QuadAtlas.BLOCK;
		}

		atlas(atlas);
		animated(materialInfo.sprite().contents().isAnimated());
		chunkLayer(materialInfo.layer());
		itemRenderType(materialInfo.itemRenderType());
		tintIndex(materialInfo.tintIndex());
		shadeDirectionOverride(materialInfo.shadeDirectionOverride());
		emissive(lightEmission == 15);
		return this;
	}

	@Override
	public final MutableQuadViewImpl clear() {
		System.arraycopy(DEFAULT_QUAD_DATA, 0, data, baseIndex, EncodingFormat.TOTAL_STRIDE);
		isGeometryInvalid = true;
		nominalFace = null;
		return this;
	}

	@Override
	public void pushTransform(QuadTransform transform) {
		if (transform == null) {
			throw new NullPointerException("QuadTransform cannot be null!");
		}

		transformStack.push(transform);

		if (transformStack.size() == 1) {
			activeTransform = transform;
		} else if (transformStack.size() == 2) {
			activeTransform = stackTransform;
		}
	}

	@Override
	public void popTransform() {
		transformStack.pop();

		if (transformStack.isEmpty()) {
			activeTransform = NO_TRANSFORM;
		} else if (transformStack.size() == 1) {
			activeTransform = transformStack.getFirst();
		}
	}

	/**
	 * Emit the quad without applying transforms and without clearing the underlying data.
	 * Geometry is not guaranteed to be valid when called, but can be computed by calling {@link #computeGeometry()}.
	 */
	protected abstract void emitDirectly();

	/**
	 * Apply transforms and then if transforms return true, emit the quad without clearing the underlying data.
	 */
	public final void transformAndEmit() {
		if (activeTransform.transform(this)) {
			emitDirectly();
		}
	}

	@Override
	public final MutableQuadViewImpl emit() {
		transformAndEmit();
		clear();
		return this;
	}
}
