/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.datagen.recipe;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.crafting.Recipe;

import net.fabricmc.fabric.api.datagen.v1.recipe.FabricRecipeOutput;

@Mixin(targets = "net.minecraft.data.recipes.RecipeProvider$1")
abstract class RecipeProviderOutputMixin implements FabricRecipeOutput {
	@Shadow
	@Final
	BootstrapContext<Recipe<?>> val$recipeOutput;

	@Override
	public Identifier getRecipeIdentifier(Identifier recipeId) {
		if (val$recipeOutput instanceof FabricRecipeOutput output) {
			return output.getRecipeIdentifier(recipeId);
		}

		return FabricRecipeOutput.super.getRecipeIdentifier(recipeId);
	}
}
